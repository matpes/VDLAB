Slike u labu su iskorišćne kako bi izradu samog laba ucinile zanimljvijim i lakšim.
Namena nije da bilo koga uvrede, već naime, kao zahvalnost asistentu Jelici na odličnim vežbama.